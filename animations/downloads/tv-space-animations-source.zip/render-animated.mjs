import fs from 'node:fs';
import path from 'node:path';
import {openBrowser,getCompositions,renderMedia} from '@remotion/renderer';
const data=JSON.parse(fs.readFileSync('animated-data.json','utf8'));
const ids=['UsbDemo','PhoneDemo','PreparationDemo','YaosDemo','SalutDemo','LinkDemo','NumDemo','ComponentsDemo'];
const serveUrl=path.resolve('out/animated-bundle');
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try{
 const comps=await getCompositions(serveUrl,{puppeteerInstance:browser});
 for(let i=0;i<data.length;i++){
  const composition=comps.find(c=>c.id===ids[i]);if(!composition)throw Error('Missing '+ids[i]);
  console.log(`START ${data[i].slug}: ${composition.durationInFrames} frames`);
  let last=-1;
  await renderMedia({serveUrl,composition,puppeteerInstance:browser,concurrency:4,codec:'h264',crf:23,x264Preset:'veryfast',outputLocation:`out/animated/${data[i].slug}-silent.mp4`,logLevel:'error',onProgress:({progress})=>{
   const milestone=Math.floor(progress*10);
   if(milestone>last){last=milestone;console.log(`${data[i].slug}: ${Math.min(100,milestone*10)}%`);}
  }});
  console.log(`DONE ${data[i].slug}`);
 }
}finally{await browser.close({silent:true});}
