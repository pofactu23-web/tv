from pathlib import Path
import json
import shutil
import subprocess
import zipfile
import html

base=Path(__file__).resolve().parent
out=base/'out/animated'
target=Path('/workspace/tv/animations')
data=json.loads((base/'animated-data.json').read_text())
for name in ['videos','voice','downloads']:(target/name).mkdir(parents=True,exist_ok=True)
if (out/'preview-usb.gif').exists():
    shutil.copyfile(out/'preview-usb.gif',target/'preview-usb.gif')
for d in data:
    shutil.copyfile(out/(d['slug']+'.mp4'),target/'videos'/(d['slug']+'.mp4'))
    shutil.copyfile(out/(d['slug']+'-voice.txt'),target/'voice'/(d['slug']+'-voice.txt'))

concat=out/'concat.txt'
concat.write_text('\n'.join(f"file '{out/(d['slug']+'.mp4')}'" for d in data))
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(out/'tv-space-all-animations.mp4')],check=True)
shutil.copyfile(out/'tv-space-all-animations.mp4',target/'videos'/'tv-space-all-animations.mp4')

chapters=[];cursor=0
for d in data:
    chapters.append(f'{cursor//60:02d}:{cursor%60:02d} — {d["title"]}')
    cursor+=d['duration']
readme='''TV SPACE — анимация демонстрационного интерфейса

1920×1080, 24 кадра/с. Анимация выполнена покадрово в Remotion: перемещение рамки выбора пультом, подсветка кнопок пульта, эффекты нажатий, открытие окон, копирование и установка с меняющимся прогрессом. Это не видеозапись конкретного телевизора и не последовательность текстовых слайдов.

Звук: собственные короткие звуки нажатия и завершения установки. Дикторской озвучки нет. Тексты находятся в voice/.
Первые два урока показывают установку USB и сетевой перенос; далее идут подготовка третьего способа, пример YaOS, заметка Салют, настройки LinkTV и NUM, установка компонентов TorrServe/VLC.
Файлы, адреса, меню и демонстрационные каналы на экране — примеры. Плейлисты, доступ к контенту и APK в этот архив не включены. Реальные названия меню и порядок запроса разрешения зависят от устройства и версии.

НЕПОЛНЫЕ ИНСТРУКЦИИ
03: исходный файл не называет приложение передачи; показана только подготовка.
05: в исходном файле нет точных действий и проверенного актуального портала Салют; отдельная заметка вместо выдуманной рабочей процедуры.
08: исходный файл не содержит параметры сервера; установку компонентов показали, настройки не выдумывали.

НЕЙРООЗВУЧКА
ElevenLabs (https://elevenlabs.io), Text to Speech: выбрать русский голос, прослушать пример, вставить текст отдельного урока из voice/, скачать MP3/WAV. Альтернатива: SpeechGen (https://speechgen.io/ru/).
Для продажи проверьте коммерческие права выбранного тарифа. Актуальные цены и региональная доступность не проверены.
Пришлите полученные MP3/WAV: временные интервалы действий можно перестроить под нормальную речь. Не нужно искусственно ускорять голос под готовый ролик.

ОГЛАВЛЕНИЕ
'''+ '\n'.join(chapters)+'\n\nПРИМЕЧАНИЯ ПО УРОКАМ\n'+'\n'.join(d['slug']+': '+d['note'] for d in data)+'\n'
(out/'README.txt').write_text(readme)
(out/'chapters.txt').write_text('\n'.join(chapters)+'\n')
(target/'README.txt').write_text(readme)
shutil.copyfile(out/'chapters.txt',target/'voice'/'chapters.txt')

with zipfile.ZipFile(out/'tv-space-animations.zip','w',zipfile.ZIP_DEFLATED) as z:
    for d in data:
        z.write(out/(d['slug']+'.mp4'),'videos/'+d['slug']+'.mp4')
        z.write(out/(d['slug']+'-voice.txt'),'voice/'+d['slug']+'-voice.txt')
    z.write(out/'README.txt','README.txt')
    z.write(out/'chapters.txt','chapters.txt')
shutil.copyfile(out/'tv-space-animations.zip',target/'downloads'/'tv-space-animations.zip')

with zipfile.ZipFile(out/'tv-space-animations-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in ['package.json','package-lock.json','tsconfig.json','remotion.config.ts','build-animated-data.py','animated-data.json','render-animated.mjs','check-animated-frames.mjs','animated-audio.py','package-animated.py']:
        z.write(base/name,name)
    for f in (base/'src').rglob('*'):
        if f.is_file():z.write(f,str(f.relative_to(base)))
    z.writestr('README-animation.txt','Install: npm ci; Python with numpy; FFmpeg; Chromium. Rebuild: python build-animated-data.py; npx remotion bundle src/animated/index.ts --out-dir=out/animated-bundle; node render-animated.mjs; python animated-audio.py. Source: src/animated/Screen.tsx and individually registered lesson components. All frame animations are driven by useCurrentFrame; no CSS animation or static-frame encoding used. Registration: src/animated/index.ts. Render uses Chromium at /usr/bin/chromium and concurrency 4.\n')
shutil.copyfile(out/'tv-space-animations-source.zip',target/'downloads'/'tv-space-animations-source.zip')

cards=''
for d in data:
    title=html.escape(d['title']);slug=d['slug'];note=html.escape(d['note'])
    cards+=f'<article><h2>{title}</h2><p>{d["duration"]} сек. · {note}</p><video controls preload="none" src="videos/{slug}.mp4"></video><div class="links"><a download href="videos/{slug}.mp4">Скачать MP4</a><a href="voice/{slug}-voice.txt">Текст нейроозвучки</a></div></article>'
page='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>TV SPACE — анимация интерфейса</title><style>
*{box-sizing:border-box}body{margin:0;background:#080f1a;color:#eef6ff;font-family:Arial,sans-serif;line-height:1.5}main{max-width:1200px;padding:30px 20px 70px;margin:auto}h1{font-size:clamp(30px,5vw,48px)}h2{font-size:25px}.tag{color:#78e9ff;font-weight:bold;letter-spacing:3px}p{color:#b4c8dd}article{background:#101e30;border:1px solid #2a405a;padding:24px;border-radius:22px;margin:26px 0}video{width:100%;aspect-ratio:16/9;background:#03070d;border-radius:12px}.links{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}a{display:inline-block;background:#183e53;color:#b8ffff;padding:10px 16px;border-radius:10px;text-decoration:none}a:focus-visible{outline:3px solid #78e9ff}.notice{padding:18px;border-left:4px solid #78e9ff;background:#102436}</style><main><div class="tag">TV SPACE</div><h1>Анимация интерфейса телевизора</h1><p class="notice">Демонстрационные экраны: пульт, перемещение выделения, открытие файлового менеджера, флешка, выбор APK и установка. Звуки нажатий добавлены; дикторскую озвучку можно сделать по готовым текстам. Это имитация интерфейса, не запись конкретной модели ТВ.</p><div class="links"><a download href="downloads/tv-space-animations.zip">Скачать весь комплект ZIP</a><a download href="downloads/tv-space-animations-source.zip">Редактируемый проект</a><a href="../lessons/">Предыдущие схемы уроков</a></div>'''+cards+'''<article><h2>Все материалы одним видео · 4:36</h2><video controls preload="none" src="videos/tv-space-all-animations.mp4"></video><div class="links"><a download href="videos/tv-space-all-animations.mp4">Скачать общий MP4</a><a href="voice/chapters.txt">Оглавление</a></div></article><article><h2>Где сделать естественный голос</h2><p>ElevenLabs → Text to Speech → русский голос → короткий образец → текст урока → экспорт MP3/WAV. Альтернатива — SpeechGen. Для продажи проверьте коммерческие права выбранного тарифа. После создания аудио длительность сцен можно адаптировать под речь.</p><div class="links"><a href="https://elevenlabs.io" target="_blank" rel="noopener noreferrer">ElevenLabs</a><a href="https://speechgen.io/ru/" target="_blank" rel="noopener noreferrer">SpeechGen</a></div></article></main></html>'''
(target/'index.html').write_text(page)
print('Eight animated videos, ZIP, voice scripts and review page packaged.',flush=True)
