import {ScreenDemo} from './Screen';
import {demos} from './data';
export const PreparationDemo=()=> <ScreenDemo demo={demos[2]}/>;
