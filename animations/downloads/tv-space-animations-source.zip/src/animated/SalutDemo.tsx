import {ScreenDemo} from './Screen';
import {demos} from './data';
export const SalutDemo=()=> <ScreenDemo demo={demos[4]}/>;
