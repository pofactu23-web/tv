import {ScreenDemo} from './Screen';
import {demos} from './data';
export const PhoneDemo=()=> <ScreenDemo demo={demos[1]}/>;
