import {ScreenDemo} from './Screen';
import {demos} from './data';
export const ComponentsDemo=()=> <ScreenDemo demo={demos[7]}/>;
