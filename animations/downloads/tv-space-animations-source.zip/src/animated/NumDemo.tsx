import {ScreenDemo} from './Screen';
import {demos} from './data';
export const NumDemo=()=> <ScreenDemo demo={demos[6]}/>;
