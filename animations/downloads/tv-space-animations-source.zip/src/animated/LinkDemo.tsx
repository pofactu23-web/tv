import {ScreenDemo} from './Screen';
import {demos} from './data';
export const LinkDemo=()=> <ScreenDemo demo={demos[5]}/>;
