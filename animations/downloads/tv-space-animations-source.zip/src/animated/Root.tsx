import {Composition} from 'remotion';
import {UsbDemo} from "./UsbDemo";
import {PhoneDemo} from "./PhoneDemo";
import {PreparationDemo} from "./PreparationDemo";
import {YaosDemo} from "./YaosDemo";
import {SalutDemo} from "./SalutDemo";
import {LinkDemo} from "./LinkDemo";
import {NumDemo} from "./NumDemo";
import {ComponentsDemo} from "./ComponentsDemo";
export const AnimatedRoot=()=> <><Composition id="UsbDemo" component={UsbDemo} width={1920} height={1080} fps={24} durationInFrames={56*24}/>
<Composition id="PhoneDemo" component={PhoneDemo} width={1920} height={1080} fps={24} durationInFrames={48*24}/>
<Composition id="PreparationDemo" component={PreparationDemo} width={1920} height={1080} fps={24} durationInFrames={20*24}/>
<Composition id="YaosDemo" component={YaosDemo} width={1920} height={1080} fps={24} durationInFrames={37*24}/>
<Composition id="SalutDemo" component={SalutDemo} width={1920} height={1080} fps={24} durationInFrames={18*24}/>
<Composition id="LinkDemo" component={LinkDemo} width={1920} height={1080} fps={24} durationInFrames={37*24}/>
<Composition id="NumDemo" component={NumDemo} width={1920} height={1080} fps={24} durationInFrames={29*24}/>
<Composition id="ComponentsDemo" component={ComponentsDemo} width={1920} height={1080} fps={24} durationInFrames={31*24}/></>;
