import {ScreenDemo} from './Screen';
import {demos} from './data';
export const UsbDemo=()=> <ScreenDemo demo={demos[0]}/>;
