import {registerRoot} from 'remotion';
import {AnimatedRoot} from './Root';
registerRoot(AnimatedRoot);
