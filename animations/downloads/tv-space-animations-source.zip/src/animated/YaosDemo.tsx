import {ScreenDemo} from './Screen';
import {demos} from './data';
export const YaosDemo=()=> <ScreenDemo demo={demos[3]}/>;
