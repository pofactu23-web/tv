import json
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np

base=Path(__file__).resolve().parent
data=json.loads((base/'animated-data.json').read_text())
out=base/'out/animated'
rate=48000
for demo in data:
    audio=np.zeros(demo['duration']*rate,dtype=np.float64)
    for action in demo['actions']:
        if action.get('key'):
            t=np.arange(int(.07*rate))/rate
            gain=.13 if action['key']=='ok' else .085
            sound=gain*(np.sin(2*np.pi*950*t)+.2*np.sin(2*np.pi*1900*t))*np.exp(-t*78)*np.minimum(1,t/.002)
            start=round((action['at']+.035)*rate)
            audio[start:start+len(sound)]+=sound
        if action['screen']=='installed':
            t=np.arange(int(.28*rate))/rate
            sound=.075*(np.sin(2*np.pi*740*t)+.55*np.sin(2*np.pi*1110*t))*np.exp(-t*13)*np.minimum(1,t/.006)
            start=round((action['at']+.04)*rate)
            audio[start:start+len(sound)]+=sound
    assert np.max(np.abs(audio))<.9
    with wave.open(str(out/(demo['slug']+'-clicks.wav')),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate)
        w.writeframes((np.clip(audio,-1,1)*32767).astype('<i2').tobytes())
print('Original click and confirmation sounds generated for eight videos.',flush=True)
if '--prepare' in sys.argv:
    sys.exit(0)
for demo in data:
    video=out/(demo['slug']+'-silent.mp4')
    assert video.exists(),video
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(video),'-i',str(out/(demo['slug']+'-clicks.wav')),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out/(demo['slug']+'.mp4'))],check=True)
    print('Added interaction sound:',demo['slug'],flush=True)
