import fs from 'node:fs';
import path from 'node:path';
import {openBrowser,getCompositions,renderStill} from '@remotion/renderer';
const serveUrl=path.resolve('out/animated-bundle');
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try{
 const comps=await getCompositions(serveUrl,{puppeteerInstance:browser});
 const frames=[['UsbDemo',7.05],['UsbDemo',7.5],['UsbDemo',12.8],['UsbDemo',16.4],['UsbDemo',22.5],['UsbDemo',27.2],['UsbDemo',34.4],['UsbDemo',37.3],['UsbDemo',40.0],['UsbDemo',47.5],['PhoneDemo',24.5],['LinkDemo',18.5],['NumDemo',19.5]];
 fs.mkdirSync('out/animated/checks',{recursive:true});
 for(const [id,seconds] of frames){
  const comp=comps.find(c=>c.id===id);if(!comp)throw Error('Missing '+id);
  await renderStill({serveUrl,composition:comp,puppeteerInstance:browser,frame:Math.round(seconds*24),imageFormat:'png',output:`out/animated/checks/${id}-${seconds}.png`});
 }
 console.log('13 animation frames rendered: focus, files, permission, progress and success.');
}finally{await browser.close({silent:true});}
