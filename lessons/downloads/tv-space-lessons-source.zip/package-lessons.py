import html
import json
import shutil
import zipfile
from pathlib import Path

base = Path(__file__).resolve().parent
out = base/'out/lessons'
target = Path('/workspace/tv/lessons')
lessons = json.loads((base/'lessons-data.json').read_text())
for directory in ['videos','voice','downloads']:
    (target/directory).mkdir(parents=True, exist_ok=True)

chapters=[]
cursor=0
for lesson in lessons:
    duration=sum(s['seconds'] for s in lesson['steps'])
    chapters.append(f'{cursor//60:02d}:{cursor%60:02d} — {lesson["title"]} ({duration} сек.)')
    cursor+=duration
    shutil.copyfile(out/(lesson['slug']+'.mp4'),target/'videos'/(lesson['slug']+'.mp4'))
    for suffix in ['-voice.txt','-voice-clean.txt']:
        shutil.copyfile(out/(lesson['slug']+suffix),target/'voice'/(lesson['slug']+suffix))

readme='''TV SPACE — восемь видеоуроков по присланным письменным инструкциям

Формат: MP4, H.264, 1920×1080, 25 кадров/с. Без звуковой дорожки; отдельные тексты для естественной нейроозвучки подготовлены.
Видеоряд состоит из схем действий с выделением нужного пункта, мягким движением кадра и переходами. Это не запись экрана телевизора.

Материалы для просмотра и проверки перед продажей. Работа на каждом устройстве не подтверждена. Пользователь сообщает об успешной работе своего комплекта на Haier; модель и версии не установлены.
Урок 03 содержит только подготовку: исходный третий способ неполный. Для Салюта нужно проверить актуальность портала и точные действия. Урок NUM описывает только параметр из файла. Урок TorrServe/VLC не заменяет отсутствующую инструкцию подключения сервера.
Инструкции по YouTube и плейлисты для проверки 5000+ каналов не предоставлены; такие уроки и обещания не включены.

КАК ОЗВУЧИТЬ
Рекомендуемый вариант: ElevenLabs, https://elevenlabs.io — раздел Text to Speech. Выберите поддерживающий русский язык голос, прослушайте короткий образец, затем озвучивайте каждый урок отдельно.
Альтернатива: SpeechGen, https://speechgen.io/ru/ — русский голос, предварительное прослушивание, экспорт MP3/WAV.
Для продажи проверьте коммерческие права выбранного тарифа. Условия, цены и региональная доступность сервисов здесь не проверялись.

Файлы *-voice-clean.txt: цельный текст урока для вставки в сервис. Файлы *-voice.txt: текст с длительностью каждой сцены. Предпочтительно генерировать отдельный файл на сцену, чтобы легче совместить голос и видео.
Не озвучивайте заголовки, номера сцен и интервалы времени. После получения аудио пришлите MP3/WAV; длительность сцен можно подстроить под голос, не ускоряя речь чрезмерно.

Источники: 1 способ комментарии.txt, 2 способ комментарии.txt, 3 способ комментарии.txt, ЯНДЕКС ТВ он же YaOS.txt, Сбер, Салют.txt, Внимание!.txt.
Редакторские изменения: одинаковая частота Wi-Fi не требуется; Ethernet не исключается; USB-отладка не объявляется обязательной; форматирование сопровождается пояснением удаления данных; несовпадающие пункты меню не выдаются за проверенный интерфейс; неизвестные настройки сервера не выдуманы.

ОГЛАВЛЕНИЕ ОБЩЕГО РОЛИКА
'''+ '\n'.join(chapters)+'\n'
(out/'README.txt').write_text(readme)
(out/'chapters.txt').write_text('\n'.join(chapters)+'\n')
(target/'README.txt').write_text(readme)
(target/'voice'/'chapters.txt').write_text('\n'.join(chapters)+'\n')
shutil.copyfile(out/'tv-space-all-lessons.mp4',target/'videos'/'tv-space-all-lessons.mp4')

with zipfile.ZipFile(out/'tv-space-lessons.zip','w',zipfile.ZIP_DEFLATED) as z:
    for lesson in lessons:
        z.write(out/(lesson['slug']+'.mp4'),'videos/'+lesson['slug']+'.mp4')
        for suffix in ['-voice.txt','-voice-clean.txt']:
            z.write(out/(lesson['slug']+suffix),'voice/'+lesson['slug']+suffix)
    z.write(out/'README.txt','README.txt')
    z.write(out/'chapters.txt','chapters.txt')
shutil.copyfile(out/'tv-space-lessons.zip',target/'downloads'/'tv-space-lessons.zip')

with zipfile.ZipFile(out/'tv-space-lessons-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in ['package.json','package-lock.json','tsconfig.json','remotion.config.ts','lessons-data.json','build-lessons-data.py','render-lessons-frames.mjs','encode-lessons.py','package-lessons.py']:
        z.write(base/name,name)
    for f in (base/'src').rglob('*'):
        if f.is_file():z.write(f,str(f.relative_to(base)))
    z.writestr('README-lessons.txt','Rebuild: npm ci; python build-lessons-data.py; npx remotion bundle src/lessons/index.ts; node render-lessons-frames.mjs; python encode-lessons.py. Requires Node.js, Python, FFmpeg, Chromium at /usr/bin/chromium. Main composition sources: src/lessons. Separate still rendering and FFmpeg encoding preserve readable scenes and avoid rendering identical frames repeatedly. No voice is included.\n')
shutil.copyfile(out/'tv-space-lessons-source.zip',target/'downloads'/'tv-space-lessons-source.zip')

cards=''
for lesson in lessons:
    title=html.escape(lesson['title']);slug=lesson['slug'];seconds=sum(s['seconds'] for s in lesson['steps'])
    note=html.escape(lesson['note'])
    cards+=f'<article><h2>{title}</h2><p>{seconds} сек. · {note}</p><video controls preload="none" src="videos/{slug}.mp4"></video><div class="links"><a download href="videos/{slug}.mp4">Скачать MP4</a><a download href="voice/{slug}-voice-clean.txt">Текст озвучки</a><a download href="voice/{slug}-voice.txt">Текст по сценам</a></div></article>'
page='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>TV SPACE — видеоуроки</title><style>
*{box-sizing:border-box}body{margin:0;background:#080f1a;color:#eef6ff;font-family:Arial,sans-serif;line-height:1.5}main{max-width:1120px;padding:30px 20px 70px;margin:auto}h1{font-size:clamp(30px,5vw,48px)}h2{font-size:24px}.tag{color:#63edee;font-weight:bold;letter-spacing:3px}p{color:#b4c8dd}article{background:#101e30;border:1px solid #2a405a;padding:24px;border-radius:22px;margin:26px 0}video{width:100%;aspect-ratio:16/9;background:#03070d;border-radius:12px}.links{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}a{display:inline-block;background:#183e53;color:#b8ffff;padding:10px 16px;border-radius:10px;text-decoration:none}a:focus-visible{outline:3px solid #63edee}.notice{padding:18px;border-left:4px solid #63edee;background:#102436}li{margin:10px 0}</style><main><div class="tag">TV SPACE</div><h1>Восемь видеоуроков</h1><p class="notice">Версия для проверки по письменным инструкциям. Меню показано схематично; названия на вашем телевизоре могут отличаться. Видео пока без звука — тексты для нейроозвучки доступны ниже.</p><div class="links"><a download href="downloads/tv-space-lessons.zip">Скачать все уроки и тексты ZIP</a><a download href="downloads/tv-space-lessons-source.zip">Редактируемый проект</a></div><article><h2>Все уроки одним роликом · 5:17</h2><video controls preload="none" src="videos/tv-space-all-lessons.mp4"></video><div class="links"><a download href="videos/tv-space-all-lessons.mp4">Скачать общий MP4</a><a href="voice/chapters.txt">Оглавление</a></div></article>'''+cards+'''<article><h2>Где сделать естественную озвучку</h2><p>ElevenLabs: Text to Speech → голос с поддержкой русского → короткий образец → вставить текст урока → экспорт MP3. Альтернатива — SpeechGen с русским голосом. Для продажи проверьте коммерческие права выбранного тарифа.</p><div class="links"><a href="https://elevenlabs.io" target="_blank" rel="noopener noreferrer">ElevenLabs</a><a href="https://speechgen.io/ru/" target="_blank" rel="noopener noreferrer">SpeechGen</a></div><p>Пришлите готовую озвучку MP3/WAV: длительность сцен можно подстроить под речь. Лучше делать отдельное аудио для каждой сцены по соответствующему текстовому файлу.</p></article></main></html>'''
(target/'index.html').write_text(page)
print('Packaged videos, narration scripts, ZIP and review page.',flush=True)
