import fs from 'node:fs';
import path from 'node:path';
import {openBrowser,getCompositions,renderStill} from '@remotion/renderer';

const data=JSON.parse(fs.readFileSync('lessons-data.json','utf8'));
const ids=['UsbLesson','PhoneLesson','PreparationLesson','YaosLesson','SalutLesson','LinkLesson','NumLesson','ComponentsLesson'];
const serveUrl=path.resolve('build');
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try{
 const comps=await getCompositions(serveUrl,{puppeteerInstance:browser});
 for(let n=0;n<data.length;n++){
  const lesson=data[n], composition=comps.find(c=>c.id===ids[n]);
  if(!composition)throw Error('Missing composition '+ids[n]);
  const output=path.resolve('out/lessons/frames',lesson.slug);
  fs.mkdirSync(output,{recursive:true});
  let cursor=0;
  for(let i=0;i<lesson.steps.length;i++){
   await renderStill({serveUrl,composition,puppeteerInstance:browser,frame:(cursor+2)*25,output:path.join(output,`${i}.png`),imageFormat:'png'});
   cursor+=lesson.steps[i].seconds;
  }
  console.log(lesson.slug+': '+lesson.steps.length+' frames rendered');
 }
}finally{await browser.close({silent:true});}
