import {Composition,Series,useVideoConfig} from 'remotion';
import {Intro} from './Intro';
import {Compatibility} from './Compatibility';
import {Download} from './Download';
import {Transfer} from './Transfer';
import {Connect} from './Connect';
import {Install} from './Install';
import {Finish} from './Finish';
export const TVSpace=()=>{const {fps}=useVideoConfig();return <Series><Series.Sequence durationInFrames={8*fps} premountFor={fps} name="Intro"><Intro/></Series.Sequence>
<Series.Sequence durationInFrames={10*fps} premountFor={fps} name="Compatibility"><Compatibility/></Series.Sequence>
<Series.Sequence durationInFrames={12*fps} premountFor={fps} name="Download"><Download/></Series.Sequence>
<Series.Sequence durationInFrames={10*fps} premountFor={fps} name="Transfer"><Transfer/></Series.Sequence>
<Series.Sequence durationInFrames={10*fps} premountFor={fps} name="Connect"><Connect/></Series.Sequence>
<Series.Sequence durationInFrames={12*fps} premountFor={fps} name="Install"><Install/></Series.Sequence>
<Series.Sequence durationInFrames={8*fps} premountFor={fps} name="Finish"><Finish/></Series.Sequence></Series>};
export const RemotionRoot=()=> <><Composition id="TVSpace" component={TVSpace} width={1920} height={1080} fps={30} durationInFrames={2100}/><Composition id="Intro" component={Intro} width={1920} height={1080} fps={30} durationInFrames={8*30}/>
<Composition id="Compatibility" component={Compatibility} width={1920} height={1080} fps={30} durationInFrames={10*30}/>
<Composition id="Download" component={Download} width={1920} height={1080} fps={30} durationInFrames={12*30}/>
<Composition id="Transfer" component={Transfer} width={1920} height={1080} fps={30} durationInFrames={10*30}/>
<Composition id="Connect" component={Connect} width={1920} height={1080} fps={30} durationInFrames={10*30}/>
<Composition id="Install" component={Install} width={1920} height={1080} fps={30} durationInFrames={12*30}/>
<Composition id="Finish" component={Finish} width={1920} height={1080} fps={30} durationInFrames={8*30}/></>;
