import {Frame,Card} from './Design';
export const Connect=()=> <Frame step={"ШАГ 03 / ТЕЛЕВИЗОР"} title={"Откройте\nфайлы на ТВ"} subtitle={"Подключите флешку к телевизору. Запустите файловый менеджер."} caption={"Найдите USB-накопитель и выберите нужный APK-файл."} kind={"tv"}><Card>USB-накопитель → папка с APK</Card><Card>Названия меню зависят от модели ТВ</Card></Frame>;
