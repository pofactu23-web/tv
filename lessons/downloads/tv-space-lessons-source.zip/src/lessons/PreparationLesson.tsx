import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const PreparationLesson=()=> <Tutorial lesson={lessons[2]} lessonNumber={3}/>;
