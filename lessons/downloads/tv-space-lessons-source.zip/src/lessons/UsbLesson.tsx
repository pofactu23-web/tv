import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const UsbLesson=()=> <Tutorial lesson={lessons[0]} lessonNumber={1}/>;
