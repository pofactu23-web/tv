import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

export type LessonStep = {title:string;text:string;menu:string[];active:number;caption:string;speech:string;seconds:number};
export type LessonData = {slug:string;title:string;source:string;note:string;steps:LessonStep[]};

export const LessonSlide = ({lesson,step,index,lessonNumber}:{lesson:LessonData;step:LessonStep;index:number;lessonNumber:number}) => {
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{background:'radial-gradient(ellipse at 78% 36%,#193758 0%,#0d1a2b 40%,#070c14 80%)',color:'#f1f7ff',fontFamily:'Arial, sans-serif',padding:'65px 105px'}}>
  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
   <div style={{fontSize:34,fontWeight:800,letterSpacing:4}}>TV <span style={{color:'#63edee'}}>SPACE</span></div>
   <div style={{fontSize:25,color:'#96abc2',letterSpacing:2}}>ВИДЕОРУКОВОДСТВО • УРОК {String(lessonNumber).padStart(2,'0')}</div>
  </div>
  <div style={{marginTop:36,color:'#90abc7',fontSize:30}}>{lesson.title}</div>
  <div style={{flex:1,display:'flex',alignItems:'center',gap:65}}>
   <div style={{width:775,flexShrink:0,translate:interpolate(frame,[0,.7*fps],['0px 20px','0px 0px'],{extrapolateRight:'clamp'})}}>
    <div style={{fontSize:27,color:'#63edee',letterSpacing:4,marginBottom:26}}>ШАГ {String(index+1).padStart(2,'0')} / {String(lesson.steps.length).padStart(2,'0')}</div>
    <div style={{fontSize:75,fontWeight:800,lineHeight:1.12,letterSpacing:-2,whiteSpace:'pre-line',marginBottom:30}}>{step.title}</div>
    <div style={{fontSize:36,lineHeight:1.42,color:'#bacce0'}}>{step.text}</div>
   </div>
   <div style={{width:845,padding:'34px 33px',background:'#0b1523',border:'2px solid #2f4762',borderRadius:30,boxShadow:'0 28px 65px #0006'}}>
    <div style={{display:'flex',gap:10,alignItems:'center',marginBottom:30}}><span style={{width:11,height:11,borderRadius:10,background:'#63edee'}}/><span style={{fontSize:23,color:'#93a9c1',letterSpacing:2}}>СХЕМА ДЕЙСТВИЙ</span></div>
    <div style={{display:'flex',flexDirection:'column',gap:16}}>
     {step.menu.map((label,i)=><div key={label} style={{padding:'23px 22px',borderRadius:15,display:'flex',alignItems:'center',gap:20,border:i===step.active?'2px solid #63edee':'2px solid #23384f',background:i===step.active?'#173c50':'#101e30',color:i===step.active?'#f2ffff':'#a9bed3',fontSize:31,lineHeight:1.28}}>
      <span style={{fontSize:24,color:i===step.active?'#63edee':'#637e99',minWidth:33}}>{i===step.active?'▶':String(i+1).padStart(2,'0')}</span><span>{label}</span>
     </div>)}
    </div>
   </div>
  </div>
  <div style={{borderTop:'1px solid #2b3e53',paddingTop:23,minHeight:111,fontSize:29,lineHeight:1.4,color:'#bed0e3',display:'flex',gap:20,alignItems:'center'}}><div style={{color:'#63edee',fontSize:33}}>ⓘ</div><div>{step.caption}</div></div>
  <div style={{display:'flex',gap:12,paddingTop:13}}>{lesson.steps.map((s,i)=><div key={s.title} style={{height:5,flex:1,borderRadius:5,background:i<=index?'#63edee':'#25384c'}}/>)}</div>
 </AbsoluteFill>;
};
