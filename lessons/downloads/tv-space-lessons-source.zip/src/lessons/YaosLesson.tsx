import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const YaosLesson=()=> <Tutorial lesson={lessons[3]} lessonNumber={4}/>;
