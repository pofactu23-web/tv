import {Series,useVideoConfig} from 'remotion';
import {LessonSlide,LessonData} from './LessonSlide';

// Steps intentionally use one shared source template, controlled by the lesson data.
export const Tutorial=({lesson,lessonNumber}:{lesson:LessonData;lessonNumber:number})=>{
 const {fps}=useVideoConfig();
 return <Series>{lesson.steps.map((step,index)=><Series.Sequence key={step.title} name={step.title.replace('\n',' ')} durationInFrames={step.seconds*fps} premountFor={fps}><LessonSlide lesson={lesson} step={step} index={index} lessonNumber={lessonNumber}/></Series.Sequence>)}</Series>;
};
