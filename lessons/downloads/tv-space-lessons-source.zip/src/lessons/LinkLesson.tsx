import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const LinkLesson=()=> <Tutorial lesson={lessons[5]} lessonNumber={6}/>;
