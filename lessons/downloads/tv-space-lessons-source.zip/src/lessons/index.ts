import {registerRoot} from 'remotion';
import {LessonsRoot} from './LessonsRoot';
registerRoot(LessonsRoot);
