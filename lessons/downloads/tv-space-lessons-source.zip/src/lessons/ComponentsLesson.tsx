import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const ComponentsLesson=()=> <Tutorial lesson={lessons[7]} lessonNumber={8}/>;
