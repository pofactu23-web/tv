import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const NumLesson=()=> <Tutorial lesson={lessons[6]} lessonNumber={7}/>;
