import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const SalutLesson=()=> <Tutorial lesson={lessons[4]} lessonNumber={5}/>;
