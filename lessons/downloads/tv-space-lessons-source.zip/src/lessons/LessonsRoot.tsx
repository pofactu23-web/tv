import {Composition} from 'remotion';
import {UsbLesson} from "./UsbLesson";
import {PhoneLesson} from "./PhoneLesson";
import {PreparationLesson} from "./PreparationLesson";
import {YaosLesson} from "./YaosLesson";
import {SalutLesson} from "./SalutLesson";
import {LinkLesson} from "./LinkLesson";
import {NumLesson} from "./NumLesson";
import {ComponentsLesson} from "./ComponentsLesson";
export const LessonsRoot=()=> <><Composition id="UsbLesson" component={UsbLesson} width={1920} height={1080} fps={25} durationInFrames={48*25}/>
<Composition id="PhoneLesson" component={PhoneLesson} width={1920} height={1080} fps={25} durationInFrames={50*25}/>
<Composition id="PreparationLesson" component={PreparationLesson} width={1920} height={1080} fps={25} durationInFrames={29*25}/>
<Composition id="YaosLesson" component={YaosLesson} width={1920} height={1080} fps={25} durationInFrames={38*25}/>
<Composition id="SalutLesson" component={SalutLesson} width={1920} height={1080} fps={25} durationInFrames={31*25}/>
<Composition id="LinkLesson" component={LinkLesson} width={1920} height={1080} fps={25} durationInFrames={45*25}/>
<Composition id="NumLesson" component={NumLesson} width={1920} height={1080} fps={25} durationInFrames={38*25}/>
<Composition id="ComponentsLesson" component={ComponentsLesson} width={1920} height={1080} fps={25} durationInFrames={38*25}/></>;
