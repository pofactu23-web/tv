import {Tutorial} from './Tutorial';
import {lessons} from './data';
export const PhoneLesson=()=> <Tutorial lesson={lessons[1]} lessonNumber={2}/>;
