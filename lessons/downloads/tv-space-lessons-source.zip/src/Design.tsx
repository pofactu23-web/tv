import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
export const Icon=({kind}:{kind:string})=><svg width="310" height="270" viewBox="0 0 310 270" fill="none" stroke="#63edee" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round">
{kind==='usb'?<><rect x="96" y="80" width="118" height="165" rx="28"/><path d="M120 80V28h70v52M138 43v15m34-15v15"/><path d="M155 190v-64m0 25-25-20m25 38 26-21"/></>:kind==='folder'?<><path d="M25 70V45h100l26 25h132v167H25Z"/><path d="M110 145h90m-45-38v79m-26-27 26 27 26-27"/></>:kind==='check'?<><circle cx="155" cy="132" r="104"/><path d="m100 132 40 40 75-82"/></>:<><rect x="15" y="24" width="280" height="180" rx="18"/><path d="M120 204v35m70-35v35M90 240h130"/><path d="m133 80 65 35-65 35Z" fill="#63edee" stroke="none"/></>}
</svg>;
export const Card=({children}:{children:React.ReactNode})=><div style={{background:'#152039',border:'2px solid #344568',borderRadius:22,padding:'19px 25px',fontSize:31,lineHeight:1.35}}>{children}</div>;
export const Frame=({step,title,subtitle,caption,kind,children}:{step:string;title:string;subtitle:string;caption:string;kind:string;children?:React.ReactNode})=>{
 const f=useCurrentFrame();const {fps,durationInFrames}=useVideoConfig();
 return <AbsoluteFill style={{fontFamily:'Arial, sans-serif',color:'#f6f9ff',background:'radial-gradient(ellipse at 78% 35%, #1d3a65 0%, #101a30 35%, #070a12 76%)',padding:'72px 112px'}}>
 <div style={{display:'flex',justifyContent:'space-between',fontSize:30,fontWeight:800,letterSpacing:5}}><span>TV <span style={{color:'#63edee'}}>SPACE</span></span><span style={{color:'#8c9db9',fontSize:24,letterSpacing:2}}>ИНСТРУКЦИЯ • ANDROID TV</span></div>
 <div style={{display:'flex',alignItems:'center',flex:1,gap:75,opacity:interpolate(f,[0,.65*fps,durationInFrames-.4*fps,durationInFrames],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),translate:interpolate(f,[0,.7*fps],['0px 30px','0px 0px'],{extrapolateRight:'clamp'})}}>
 <div style={{width:990}}><div style={{fontSize:28,letterSpacing:5,color:'#63edee',marginBottom:30}}>{step}</div><h1 style={{fontSize:94,lineHeight:1.06,letterSpacing:-3,margin:'0 0 32px',whiteSpace:'pre-line'}}>{title}</h1><div style={{fontSize:38,lineHeight:1.4,color:'#b4c3dd',maxWidth:900}}>{subtitle}</div></div>
 <div style={{width:600,display:'flex',flexDirection:'column',alignItems:'center',gap:20}}><div style={{filter:'drop-shadow(0 0 30px #36baff45)',scale:interpolate(f,[0,fps],[.85,1],{extrapolateRight:'clamp'})}}><Icon kind={kind}/></div><div style={{width:'100%',display:'flex',flexDirection:'column',gap:12}}>{children}</div></div>
 </div><div style={{height:96,display:'flex',alignItems:'center',justifyContent:'center',textAlign:'center',fontSize:30,lineHeight:1.4,borderTop:'1px solid #34415a',color:'#dbe6f8'}}>{caption}</div>
 <div style={{position:'absolute',bottom:0,left:0,height:5,width:interpolate(f,[0,durationInFrames],[0,1920]),background:'linear-gradient(90deg,#5da6ff,#63edee)'}}/>
 </AbsoluteFill>;
};
