import {Frame,Card} from './Design';
export const Transfer=()=> <Frame step={"ШАГ 02 / USB"} title={"Перенесите\nна флешку"} subtitle={"Скопируйте скачанные APK-файлы на USB-накопитель."} caption={"После копирования безопасно извлеките флешку из компьютера."} kind={"usb"}><Card>3 APK → USB</Card><Card>PDF можно оставить на телефоне</Card></Frame>;
