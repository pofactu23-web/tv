import {Frame,Card} from './Design';
export const Intro=()=> <Frame step={"НАЧНЁМ"} title={"Ваш телевизор.\nНовые возможности."} subtitle={"Установка приложений за четыре понятных шага."} caption={"Понадобятся компьютер, USB-флешка и телевизор на Android."} kind={"tv"}><Card>КОМПЬЮТЕР → USB → ANDROID TV</Card></Frame>;
