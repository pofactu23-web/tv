import concurrent.futures
import json
import subprocess
from pathlib import Path

base = Path(__file__).resolve().parent
out = base / 'out/lessons'
lessons = json.loads((base / 'lessons-data.json').read_text())

def run(args):
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-3000:])

def encode(lesson):
    frames = out / 'frames' / lesson['slug']
    parts = []
    for index, step in enumerate(lesson['steps']):
        source = frames / f'{index}.png'
        assert source.exists(), source
        target = frames / f'{index}.mp4'
        seconds = step['seconds']
        vf = f"scale=1940:1092,crop=1920:1080:x=10+8*sin(t*0.5):y=6,fade=t=in:st=0:d=0.22,fade=t=out:st={seconds-.22}:d=0.22,format=yuv420p"
        run(['ffmpeg', '-y', '-v', 'error', '-loop', '1', '-framerate', '25', '-i', str(source), '-t', str(seconds), '-vf', vf, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-threads', '2', '-an', '-movflags', '+faststart', str(target)])
        parts.append(target)
    concat = frames / 'concat.txt'
    concat.write_text('\n'.join(f"file '{part}'" for part in parts))
    target = out / (lesson['slug']+'.mp4')
    run(['ffmpeg', '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', str(concat), '-c', 'copy', '-movflags', '+faststart', str(target)])
    print(f"Encoded {lesson['slug']}: {sum(s['seconds'] for s in lesson['steps'])} seconds", flush=True)
    return target

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    futures = [executor.submit(encode, lesson) for lesson in lessons]
    paths = [future.result() for future in futures]

master_concat = out / 'all-concat.txt'
master_concat.write_text('\n'.join(f"file '{p}'" for p in paths))
run(['ffmpeg', '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', str(master_concat), '-c', 'copy', '-movflags', '+faststart', str(out/'tv-space-all-lessons.mp4')])
print('All lessons combined.', flush=True)
